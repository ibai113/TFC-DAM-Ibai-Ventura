package com.example.peluqueriacanina;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class mi_lista extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mi_lista);
    }
}
