package com.example.peluqueriacanina;

public class RecuperarDatosPersonales {

    public static final String DATA_URL = "https://rogdomain.ddns.net:8860/requeteguau/buscarcuenta.php?correo=";

    public static final String KEY_nombre = "nombre";
    public static final String KEY_correo = "correo";
    public static final String KEY_telefono = "telefono";
    public static final String KEY_contrasena = "contrasena";
    public static final String KEY_nombreMascota = "nombre_mascota";
    public static final String KEY_pesoMascota = "peso_mascota";
    public static final String KEY_razaMascota = "raza_mascota";
    public static final String KEY_generoMascota = "genero_mascota";

    public static final String JSON_ARRAY = "result";


}
